const My_Notes = require("../models/notesModel");
const uploadFile = require("../utils/cloudinary");

const addNotes = async (req, res) => {
  try {
    const notes = req.body;

    if (!req.file) {
      return res.status(400).json({ error: "No image file uploaded" });
    }

    // upload to cloudinary
    const imageUrl = await uploadFile(req.file);

    const newNotes = new My_Notes({
      ...notes,
      cover_image: imageUrl
    });

    const savedNotes = await newNotes.save();

    res.status(201).json(savedNotes);

  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Server error" });
  }
};


const getNotes = async (req, res) =>{
    try {
        const getdata = await My_Notes.find();
        
        res.status(200).json(getdata);
    } catch (error) {
        console.log("Error : ", error);
    }
}

module.exports = {
    addNotes,
    getNotes,
}