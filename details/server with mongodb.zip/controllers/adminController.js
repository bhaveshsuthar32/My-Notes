const jwt = require("jsonwebtoken");
const User = require("../models/regUserModel");
const bcrypt = require('bcrypt');

const REF_KEY = "user@2025";
const ACC_KEY = "user@123";


const regUser = async (req, res) => {
    const user = req.body;
    try {

        const existUser = await User.findOne({ email: user.email });
        if (existUser) {
            return res.status(409).json({ error: "Email already exist" });
        }

        const hashpassword = await bcrypt.hash(user.password, 10);

        const newUser = new User({
            ...user, password: hashpassword,
        });

        const refToken = jwt.sign({
            userId: user._id, userName: user.firstname, email: user.email
        }, REF_KEY, { expiresIn: '2d' });

        newUser.ref_token = refToken;
        const regUser = await newUser.save();

        res.status(200).json(regUser);


    } catch (error) {
        console.log('Reg Error : ', error);
    }
}

const login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const userExist = await User.findOne({ email });
        if (!userExist) {
            return res.status(404).json({ error: "User not found" });
        }

        const isMatch = await bcrypt.compare(password, userExist.password);
        if (!isMatch) {
            return res.status(401).json({ error: "Invalid password" });
        }

        const accessToken = jwt.sign(
            { userId: userExist._id, email: userExist.email },
            ACC_KEY,
            { expiresIn: "5m" }
        );

        // const refreshToken = jwt.sign(
        //     { userId: userExist._id },
        //     REF_KEY,
        //     { expiresIn: "2d" }
        // );

        const refreshToken = jwt.sign({
            userId: userExist._id, userName: userExist.firstname, email: userExist.email
        }, REF_KEY, { expiresIn: '2d' });


        userExist.ref_token = refreshToken;
        await userExist.save();

        res.status(200).json({
            accessToken,
            refreshToken
        });

    } catch (error) {
        console.log("Login Error:", error);
        res.status(500).json({ error: "Server error" });
    }
};


const getUser = async (req, res) => {
    try {
        const resData = await User.find();
        res.status(200).json(resData);
    } catch (error) {
        console.log("Error : ", error);
        res.status(500).json({ error: "Server error" });

    }
}


module.exports = {
    regUser,
    login,
    getUser,
}