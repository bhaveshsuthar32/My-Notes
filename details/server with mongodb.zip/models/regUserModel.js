const mongoose = require('mongoose');

const regUser = new mongoose.Schema({
    firstname: {
        type: String,
        required: false,
    },
    lastname: {
        type: String,
        required: false,
    },
    email: {
        type: String,
        required: false,
    },
    password: {
        type: String,
        required: false
    },
    isAdmin: {
        type: String,
        default: false,
    },
    ref_token: {
        type: String,
        required: false,
    },
    access_token: {
        type: String,
        required: false,
    },
    createdAt: {
        type: Date,
        default: Date.now, // Automatically set the registration time
    },
})

const User = mongoose.model('regUser', regUser);

module.exports = User;