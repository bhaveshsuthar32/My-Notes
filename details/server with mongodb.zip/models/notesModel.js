const mongoose = require("mongoose");

const notes = new mongoose.Schema({
    topic_name : {
        type : String,
        reuqired : false,
    },
    cover_image : {
        type : String,
        reuqired : false,
    },
    heading : {
        type : String,
        reuqired : false,
    },
    sub_heading : {
        type : String,
        reuqired : false,
    },
    special_note : {
        type : String,
        required : false,
    },
})

const My_Notes = mongoose.model('my_note', notes);

module.exports = My_Notes ; 

