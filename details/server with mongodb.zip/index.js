const express = require('express');
const app = express();
const mongodb = require('./config/db');
const router = require('./route/router');
require('dotenv').config();
const cors = require('cors');

mongodb();

const PORT = process.env.PORT || 3000;

app.use(cors());

app.use(express.json());

app.get('/test', (req,res)=>{
    res.send("hii user ✌️");
});

app.use('/', router);

app.listen(PORT, "localhost", ()=>{
    console.log(`server is running on port http://localhost:${PORT}`); 
});