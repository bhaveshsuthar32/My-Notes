const mongoose = require('mongoose');

const mongodb = async() =>{
    try {
        await mongoose.connect(process.env.DB_URL);
        console.log('db connect successfully!');
        
    } catch (error) {
        console.log('Error : ', error);
    }
}

module.exports = mongodb ;