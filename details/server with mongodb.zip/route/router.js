const express = require('express');
const router = express.Router();
const { regUser, login, getUser } = require('../controllers/adminController');
const { addNotes, getNotes } = require('../controllers/notesController');
const upload = require('../middleware/upload');

router.post('/reg-user',regUser);
router.post('/login',login);
router.get('/user', getUser);

router.post('/add-notes' , upload.single('cover_image'), addNotes);
router.get('/get-notes', getNotes);

module.exports = router;