// const express = require('express');
// const app = express();
// const mongodb = require('./config/db');
// const router = require('./route/router');
// require('dotenv').config();
// const cors = require('cors');

// mongodb();

// const PORT = process.env.PORT || 3000;

// app.use(cors());

// app.use(express.json());

// app.get('/test', (req,res)=>{
//     res.send("hii user ✌️");
// });

// app.use('/', router);

// app.listen(PORT, "localhost", ()=>{
//     console.log(`server is running on port http://localhost:${PORT}`); 
// });


// import express from "express";
// // import mongodb from "./config/db.js"; 
// // import router from "./route/router.js"; 
// import dotenv from "dotenv"; 
// import cors from "cors";
// import { connectDB } from "./config/db";
//  dotenv.config(); 

// const app = express(); 
// // mongodb(); 
// const PORT = process.env.PORT || 3000; 

// app.use(cors()); app.use(express.json()); 

// app.get("/test", (req, res) => { res.send("hii user ✌️"); }); 
// // app.use("/", router); 

// // app.listen(PORT, "localhost", () => { 
// //     console.log(`server is running on port http://localhost:${PORT}`); 
// // });

// const startServer = async () => {
//   await connectDB();

//   app.listen(PORT, () => {
//     console.log(`🚀 Server running on port ${PORT}`);
//   });
// };

// startServer();





// import express from "express";
// import dotenv from "dotenv";
// import cors from "cors";
// import { connectDB } from "./config/db.js";
// import router from "./route/router.js";

// dotenv.config();

// const app = express();
// const PORT = process.env.PORT || 3000;

// app.use(cors());
// app.use(express.json());

// app.get("/test", (req, res) => {
//   res.send("hii user ✌️");
// });

// app.use("/api", router)

// const startServer = async () => {
//   await connectDB();

//   app.listen(PORT, () => {
//     console.log(`🚀 Server running on port ${PORT}`);
//   });
// };

// startServer();



import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import router from "./route/router.js";
import { connectDB } from "./config/db.js";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use("/", router);

const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
  });
};

startServer();