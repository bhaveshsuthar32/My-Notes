// // const express = require('express');
// // const router = express.Router();
// // const { regUser, login, getUser } = require('../controllers/adminController');
// // const { addNotes, getNotes } = require('../controllers/notesController');
// // const upload = require('../middleware/upload');

// // router.post('/reg-user',regUser);
// // router.post('/login',login);
// // router.get('/user', getUser);

// // router.post('/add-notes' , upload.single('cover_image'), addNotes);
// // router.get('/get-notes', getNotes);

// // module.exports = router;


// import express from "express";
// // import { regUser, login, getUser } from "../controllers/adminController.js";
// // import { addNotes, getNotes } from "../controllers/notesController.js";
// // import upload from "../middleware/upload.js";
// import { regiterUser } from "../controllers/admint.controller.js";

// const router = express.Router();

// router.post("/reg-user", regiterUser );
// // router.post("/login", login);
// // router.get("/user", getUser);

// // router.post("/add-notes", upload.single("cover_image"), addNotes);
// // router.get("/get-notes", getNotes);

// export default router;



import express from "express";
import { registerUser, login, getUsers } from "../controllers/admin.controller.js";

const router = express.Router();

// Auth routes
router.post("/reg-user", registerUser);
router.post("/login", login);

// Get all users
router.get("/users", getUsers);

export default router;