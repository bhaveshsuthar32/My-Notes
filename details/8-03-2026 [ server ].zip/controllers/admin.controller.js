// // import pool from "../config/db";
// import pool from "../config/db.js";
// import bcrypt from "bcrypt";
// import jwt from "jsonwebtoken";

// const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET;
// const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET;

// export const regiterUser = async (req, res) =>{
//     const { firstname, lastname, email, password, isAdmin} = req.body;

//     try{
//         if(!firstname || !lastname || !email || !password ){
//             return res.status(400).json({
//                 success : false,
//                 message : "All fields are required",
//             });
//         }

//         const hashpassword = await bcrypt.hash(password, 10);

//         const result = await pool.query(
//             `INSERT INTO users (firstname, lastname, email, password, isAdmin) VALUES ($1, $2, $3, $4, $5)
//             RETURNING id firstname, lastname, email, password, isAdmin  `,
//             [
//                 firstname, lastname, email, password, isAdmin || "user"
//             ]
//         );

//             return res.status(201).json({
//       success: true,
//       user: result.rows[0],
//     });


//     }catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "User registration failed",
//     });
//   }

// };

// export const loginUser = async (req,res)=>{
//     try {
        
//     } catch (error) {
//             return res.status(500).json({
//       success: false,
//       message: "User registration failed",
//     });
//     }
// }


// export default {
//     regUser,
//     login,
//     getUser
// };



import pool from "../config/db.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET;
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET;

// ------------------- REGISTER -------------------
export const registerUser = async (req, res) => {
  const { firstname, lastname, email, password, isAdmin } = req.body;

  try {
    if (!firstname || !lastname || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    // check if user already exists
    const existingUser = await pool.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: "Email already exists",
      });
    }

    // hash password
    const hashPassword = await bcrypt.hash(password, 10);

    // insert user
    const result = await pool.query(
      `INSERT INTO users (firstname, lastname, email, password, isAdmin)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, firstname, lastname, email, isAdmin`,
      [firstname, lastname, email, hashPassword, isAdmin || "user"]
    );

    const user = result.rows[0];

    // generate tokens
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email },
      ACCESS_TOKEN_SECRET,
      { expiresIn: "15m" }
    );

    const refreshToken = jwt.sign(
      { userId: user.id, email: user.email },
      REFRESH_TOKEN_SECRET,
      { expiresIn: "7d" }
    );

    return res.status(201).json({
      success: true,
      user,
      accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "User registration failed",
    });
  }
};

// ------------------- LOGIN -------------------
export const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const result = await pool.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    const user = result.rows[0];

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid password",
      });
    }

    // generate tokens
    const accessToken = jwt.sign(
      { userId: user.id, email: user.email },
      ACCESS_TOKEN_SECRET,
      { expiresIn: "15m" }
    );

    const refreshToken = jwt.sign(
      { userId: user.id, email: user.email },
      REFRESH_TOKEN_SECRET,
      { expiresIn: "7d" }
    );

    return res.status(200).json({
      success: true,
      user: {
        id: user.id,
        firstname: user.firstname,
        lastname: user.lastname,
        email: user.email,
        isAdmin: user.isadmin,
      },
      accessToken,
      refreshToken,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Login failed",
    });
  }
};

// ------------------- GET ALL USERS -------------------
export const getUsers = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, firstname, lastname, email, isAdmin FROM users"
    );
    return res.status(200).json({
      success: true,
      users: result.rows,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch users",
    });
  }
};

export default { registerUser, login, getUsers };